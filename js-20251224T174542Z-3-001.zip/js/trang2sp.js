
        // Xử lý nút trái tim - không cho chuyển trang khi click vào nó
        document.querySelectorAll('.heart-btn').forEach(btn => {
            btn.addEventListener('click', function(event) {
                event.stopPropagation(); // Ngăn sự kiện click lan ra card cha
                this.classList.toggle('active');
                this.innerHTML = this.classList.contains('active') ? '♥' : '♡';
            });
        });
		
		function updateCartCount() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = totalItems;
    });
}
document.addEventListener('DOMContentLoaded', updateCartCount);
    
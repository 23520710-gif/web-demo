
        // === CHỨC NĂNG GIỎ HÀNG ĐỘNG ===
        function renderCart() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let tbody = document.getElementById('cartTableBody');
            let tempTotalEl = document.getElementById('tempTotal');
            let grandTotalEl = document.getElementById('grandTotal');

            if (cart.length === 0) {
                tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:80px; font-size:18px; color:#666;">Giỏ hàng của bạn đang trống</td></tr>`;
                tempTotalEl.textContent = '0 VND';
                grandTotalEl.textContent = '0 VND';
                return;
            }

            tbody.innerHTML = '';
            let total = 0;

            cart.forEach((item, index) => {
                let rowTotal = item.price * item.quantity;
                total += rowTotal;

                let row = document.createElement('tr');
                row.innerHTML = `
                    <td data-label="Sản phẩm">
                        <img src="${item.image}" alt="${item.name}" class="product-thumb">
                        <span class="product-name">${item.name}</span>
                    </td>
                    <td data-label="Giá" class="product-price">${item.price.toLocaleString()} VND</td>
                    <td data-label="Số lượng">
                        <div class="quantity-selector">
                            <button class="quantity-btn" onclick="changeQuantity(${index}, -1)">-</button>
                            <input type="text" value="${item.quantity}" class="quantity-input" readonly>
                            <button class="quantity-btn" onclick="changeQuantity(${index}, 1)">+</button>
                        </div>
                    </td>
                    <td data-label="Thành tiền" class="subtotal">${rowTotal.toLocaleString()} VND</td>
                    <td><span class="remove-btn" onclick="removeFromCart(${index})">×</span></td>
                `;
                tbody.appendChild(row);
            });

            tempTotalEl.textContent = total.toLocaleString() + ' VND';
            grandTotalEl.textContent = total.toLocaleString() + ' VND';
        }

        function changeQuantity(index, change) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart[index].quantity += change;
            if (cart[index].quantity <= 0) {
                cart.splice(index, 1);
            }
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
            updateCartCount();
        }

        function removeFromCart(index) {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart.splice(index, 1);
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
            updateCartCount();
        }

        function updateCartCount() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = totalItems;
            });
        }

        // Khi trang load
        document.addEventListener('DOMContentLoaded', () => {
            renderCart();
            updateCartCount();
        });

        // Modal đăng nhập
        document.querySelectorAll('#userBtn, #loginBtn').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                document.getElementById('authModal').classList.add('active');
            });
        });
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('authModal').classList.remove('active');
        });
        document.getElementById('authModal').addEventListener('click', function(e) {
            if (e.target === this) this.classList.remove('active');
        });
    
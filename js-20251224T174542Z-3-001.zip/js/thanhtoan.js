
    // Cập nhật số lượng giỏ hàng trên header
    function updateCartCount() {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
        document.querySelectorAll('.cart-count').forEach(el => {
            el.textContent = totalItems;
        });
    }

    // Render danh sách sản phẩm trong phần tóm tắt đơn hàng
    function renderOrderSummary() {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        let summaryContainer = document.querySelector('.order-summary');
        let itemsContainer = summaryContainer.querySelector('.summary-item:nth-of-type(1)').parentNode; // lấy phần cha chứa các item
        let tempTotal = 0;

        // Xóa các sản phẩm cũ (trừ tiêu đề và dòng tạm tính/tổng)
        let existingItems = summaryContainer.querySelectorAll('.summary-item:not(.summary-total):not(:nth-last-child(-n+3))');
        existingItems.forEach(item => item.remove());

        if (cart.length === 0) {
            summaryContainer.innerHTML = `
                <h2 class="summary-title">ĐƠN HÀNG CỦA BẠN</h2>
                <p style="text-align:center; padding:40px 0; color:#666;">Giỏ hàng trống</p>
            `;
            return;
        }

        // Thêm từng sản phẩm vào tóm tắt
        cart.forEach(item => {
            let rowTotal = item.price * (item.quantity || 1);
            tempTotal += rowTotal;

            let itemHTML = document.createElement('div');
            itemHTML.className = 'summary-item';
            itemHTML.innerHTML = `
                <div class="summary-product">
                    <img src="${item.image}" alt="${item.name}">
                    <div>
                        <div>${item.name}</div>
                        <small>x ${item.quantity || 1}</small>
                    </div>
                </div>
                <span>${rowTotal.toLocaleString()} VND</span>
            `;
            // Chèn trước dòng "Tạm tính"
            summaryContainer.querySelector('.summary-item:nth-last-child(3)').insertAdjacentElement('beforebegin', itemHTML);
        });

        // Cập nhật tạm tính và tổng
        summaryContainer.querySelector('.summary-item:nth-last-child(3) span:last-child').textContent = tempTotal.toLocaleString() + ' VND';
        summaryContainer.querySelector('.summary-total span:last-child').textContent = tempTotal.toLocaleString() + ' VND';
    }

    // Xử lý nút Đặt hàng (ví dụ: thông báo thành công và xóa giỏ hàng)
    document.querySelector('.btn-place-order').addEventListener('click', function(e) {
        e.preventDefault();
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (cart.length === 0) {
            alert('Giỏ hàng của bạn đang trống!');
            return;
        }
        if (!confirm('Xác nhận đặt hàng?')) return;

        alert('Đặt hàng thành công! Cảm ơn quý khách đã mua sắm tại Nhà UIT.\nChúng tôi sẽ liên hệ sớm nhất.');
        
        // Xóa giỏ hàng sau khi đặt thành công
        localStorage.removeItem('cart');
        updateCartCount();
        renderOrderSummary();
    });

    // Modal đăng nhập
    document.querySelectorAll('#userBtn, #loginBtn').forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('authModal').classList.add('active');
        });
    });

    document.getElementById('closeModal').addEventListener('click', () => {
        document.getElementById('authModal').classList.remove('active');
    });

    document.getElementById('authModal').addEventListener('click', e => {
        if (e.target === e.currentTarget) e.currentTarget.classList.remove('active');
    });

    // Khởi chạy khi load trang
    document.addEventListener('DOMContentLoaded', () => {
        updateCartCount();
        renderOrderSummary();
    });

window.handleLogout = function (e) {
    if (e) e.preventDefault();

    const confirmLogout = confirm('Bạn có chắc chắn muốn đăng xuất không?');
    if (!confirmLogout) return;

    
        localStorage.removeItem('loggedIn');
        localStorage.removeItem('userType');
        localStorage.removeItem('username');

        window.location.href = '/web-demo/Trangchu.html';
};
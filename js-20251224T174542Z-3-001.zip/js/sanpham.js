
        document.querySelectorAll('.icon-btn:last-child, .top-bar-right a:last-child').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                document.getElementById('authModal').classList.add('active');
            });
        });
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('authModal').classList.remove('active');
        });
        document.getElementById('authModal').addEventListener('click', function(e) {
            if (e.target === this) this.classList.remove('active');
        });
        function updateCartCount() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.querySelectorAll('.cart-count').forEach(el => el.textContent = totalItems);
        }
        document.addEventListener('DOMContentLoaded', updateCartCount);
    

        document.querySelectorAll('.accordion-header').forEach(header=>header.addEventListener('click',()=>{header.parentElement.classList.toggle('active')}));
        const thumbSwiper=new Swiper('.thumb-swiper',{spaceBetween:10,slidesPerView:5,freeMode:true,watchSlidesProgress:true});
        new Swiper('.main-swiper',{loop:true,pagination:{el:'.swiper-pagination'},navigation:{nextEl:'.swiper-button-next',prevEl:'.swiper-button-prev'},thumbs:{swiper:thumbSwiper}});
        document.querySelectorAll('.icon-btn:last-child, .top-bar-right a:last-child').forEach(item=>item.addEventListener('click',e=>{e.preventDefault();document.getElementById('authModal').classList.add('active')}));
        document.getElementById('closeModal').addEventListener('click',()=>document.getElementById('authModal').classList.remove('active'));
        document.getElementById('authModal').addEventListener('click',e=>e.target===e.currentTarget&&e.currentTarget.classList.remove('active'));
        function updateCartCount(){const cart=JSON.parse(localStorage.getItem('cart')||'[]');const total=cart.reduce((sum,item)=>sum+(item.quantity||1),0);document.querySelectorAll('.cart-count').forEach(el=>el.textContent=total)}
        document.addEventListener('DOMContentLoaded',updateCartCount);
        window.addEventListener('storage',updateCartCount);
    
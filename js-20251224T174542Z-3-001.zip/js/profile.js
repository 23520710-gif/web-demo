
// Đảm bảo các hàm có sẵn ở phạm vi toàn cục (global scope)
window.handleLogout = function (e) {
    if (e) e.preventDefault();
    // if (confirm('Bạn có chắc chắn muốn đăng xuất không?')) {
    //     localStorage.removeItem('loggedIn');
    //     localStorage.removeItem('userType');
    //     localStorage.removeItem('username');
    // }

    const confirmLogout = confirm('Bạn có chắc chắn muốn đăng xuất không?');
    if (!confirmLogout) return;

    
        localStorage.removeItem('loggedIn');
        localStorage.removeItem('userType');
        localStorage.removeItem('username');

        window.location.href = '/web-demo/Trangchu.html';
};

document.addEventListener('DOMContentLoaded', function () {
    console.log('Profile JS loaded');

    // Xử lý modal đăng nhập
    const modalTriggerBtns = document.querySelectorAll('#userBtn, #loginBtn');
    modalTriggerBtns.forEach(item => {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const modal = document.getElementById('authModal');
            if (modal) modal.classList.add('active');
        });
    });

    const closeModal = document.getElementById('closeModal');
    if (closeModal) {
        closeModal.addEventListener('click', function () {
            const modal = document.getElementById('authModal');
            if (modal) modal.classList.remove('active');
        });
    }

    const authModal = document.getElementById('authModal');
    if (authModal) {
        authModal.addEventListener('click', function (e) {
            if (e.target === this) this.classList.remove('active');
        });
    }

    // Cập nhật giỏ hàng
    updateCartCount();
});

function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelectorAll('.cart-count').forEach(el => {
        el.textContent = totalItems;
    });
}

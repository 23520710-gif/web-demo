
        // Cập nhật hiển thị tên người dùng / đăng nhập
        function updateLoginDisplay() {
            const loggedIn = localStorage.getItem('loggedIn');
            const userType = localStorage.getItem('userType');
            const username = localStorage.getItem('username');
            const loginText = document.getElementById('loginText');

            if (loggedIn === 'true') {
                if (userType === 'admin') {
                    loginText.textContent = 'Admin';
                } else {
                    loginText.textContent = username || 'Nguyễn Văn A';
                }
            } else {
                loginText.textContent = 'Đăng nhập';
                loginText.onclick = () => document.getElementById('authModal').classList.add('active');
            }
        }

        // Xử lý đăng nhập
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;

            if (username && password) {
                const userType = (username.toLowerCase() === 'admin') ? 'admin' : 'user';
                localStorage.setItem('loggedIn', 'true');
                localStorage.setItem('userType', userType);
                localStorage.setItem('username', username);

                alert('Đăng nhập thành công!');
                document.getElementById('authModal').classList.remove('active');
                updateLoginDisplay();
            } else {
                alert('Vui lòng nhập đầy đủ thông tin!');
            }
        });

        // Đăng xuất
        document.getElementById('logoutBtn').addEventListener('click', function(e) {
            e.preventDefault();
            localStorage.removeItem('loggedIn');
            localStorage.removeItem('userType');
            localStorage.removeItem('username');
            alert('Đã đăng xuất thành công!');
            updateLoginDisplay();
            location.reload();
        });

        // Click icon người 👤
        document.getElementById('userBtn').addEventListener('click', function() {
            const loggedIn = localStorage.getItem('loggedIn');
            if (loggedIn === 'true') {
                const userType = localStorage.getItem('userType');
                if (userType === 'admin') {
                    window.location.href = '/web-demo/Admin/trangadmin.html';
                } else {
                    window.location.href = '/web-demo/Pages/profile.html';
                }
            } else {
                document.getElementById('authModal').classList.add('active');
            }
        });

        // Đóng modal
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('authModal').classList.remove('active');
        });
        document.getElementById('authModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });

        // Carousel
        function scrollCarousel(dir) {
            const track = document.getElementById('carouselTrack');
            const cardWidth = track.querySelector('.product-card').offsetWidth + 30;
            track.scrollBy({ left: dir * cardWidth, behavior: 'smooth' });
        }

        // Trái tim yêu thích
        function toggleHeart(btn, event) {
            event.stopPropagation();
            btn.classList.toggle('active');
            btn.innerHTML = btn.classList.contains('active') ? '♥' : '♡';
        }

        // Newsletter
        document.querySelectorAll('.newsletter-form button').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const emailInput = btn.previousElementSibling;
                const email = emailInput.value.trim();
                if (email) {
                    alert('Cảm ơn bạn! Email ' + email + ' đã được đăng ký nhận tin tức từ Nội Thất Việt.');
                    emailInput.value = '';
                } else {
                    alert('Vui lòng nhập email của bạn!');
                }
            });
        });

        // Cập nhật giỏ hàng
        function updateCartCount() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = totalItems;
            });
        }

        // Khởi chạy khi load trang
        document.addEventListener('DOMContentLoaded', function() {
            updateLoginDisplay();
            updateCartCount();
        });
    
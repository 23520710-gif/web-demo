
        // Thumbnail click
        document.querySelectorAll('.thumbnail').forEach(thumb => {
            thumb.addEventListener('click', function() {
                document.querySelectorAll('.thumbnail').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                document.querySelector('.main-image img').src = this.src;
            });
        });

        // Quantity
        document.querySelectorAll('.quantity-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                let input = this.closest('.quantity-selector').querySelector('.quantity-input');
                let val = parseInt(input.value);
                if (this.textContent === '+') val++;
                else if (val > 1) val--;
                input.value = val;
            });
        });

        // Wishlist
        document.querySelector('.wishlist-btn').addEventListener('click', function() {
            this.classList.toggle('active');
            this.textContent = this.classList.contains('active') ? '♥' : '♡';
        });

        // Modal đăng nhập
        document.querySelectorAll('#userBtn, #loginBtn').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                document.getElementById('authModal').classList.add('active');
            });
        });
        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('authModal').classList.remove('active');
        });
        document.getElementById('authModal').addEventListener('click', function(e) {
            if (e.target === this) this.classList.remove('active');
        });

        // === CHỨC NĂNG THÊM VÀO GIỎ HÀNG ===
        document.getElementById('addToCartBtn').addEventListener('click', function() {
            let quantity = parseInt(document.getElementById('productQuantity').value);

            let product = {
                id: 'janis-001',
                name: 'Bàn Console Janis',
                price: 25900001,
                image: '/web-demo/images/sp26.jpg',
                quantity: quantity
            };
            

            // Lấy giỏ hàng hiện tại
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            // Kiểm tra sản phẩm đã có chưa
            let existing = cart.find(item => item.id === product.id);
            if (existing) {
                existing.quantity += quantity;
            } else {
                cart.push(product);
            }

            // Lưu lại
            localStorage.setItem('cart', JSON.stringify(cart));

            // Thông báo
            alert(`Đã thêm ${quantity} sản phẩm "${product.name}" vào giỏ hàng!`);

            // Cập nhật số lượng trên header
            updateCartCount();
        });

        // Cập nhật số lượng giỏ hàng trên header
        function updateCartCount() {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            let total = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.getElementById('cartCount').textContent = total;
        }

        // Khi trang load, cập nhật số lượng
        document.addEventListener('DOMContentLoaded', updateCartCount);
    
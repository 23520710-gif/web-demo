
        // Line Chart: Doanh thu theo ngày
        const ctxLine = document.getElementById('revenueLineChart').getContext('2d');
        new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: ['01/12', '02/12', '03/12', '04/12', '05/12', '06/12', '07/12', '08/12', '09/12', '10/12', '11/12', '12/12', '13/12', '14/12'],
                datasets: [{
                    label: 'Doanh thu (triệu VND)',
                    data: [80, 95, 120, 110, 150, 130, 170, 160, 200, 180, 220, 250, 230, 280],
                    borderColor: '#D2691E',
                    backgroundColor: 'rgba(210, 105, 30, 0.2)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#D2691E',
                    pointRadius: 5,
                    pointHoverRadius: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', labels: { font: { size: 14 } } },
                    tooltip: { backgroundColor: '#333', titleFont: { size: 14 }, bodyFont: { size: 14 } }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: '#eee' } },
                    x: { grid: { display: false } }
                }
            }
        });

        // Pie Chart: Phân bố danh mục
        const ctxPie = document.getElementById('categoryPieChart').getContext('2d');
        new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: ['Bàn console', 'Sofa', 'Ghế ăn', 'Bàn trà', 'Khác'],
                datasets: [{
                    data: [28.5, 22.1, 19.8, 12.3, 17.3],
                    backgroundColor: ['#D2691E', '#2c2e53', '#8B4513', '#A0522D', '#CD853F'],
                    borderWidth: 3,
                    borderColor: '#fff',
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'right', labels: { font: { size: 14 }, padding: 20 } },
                    tooltip: { backgroundColor: '#333' }
                }
            }
        });
    